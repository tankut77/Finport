import type { Currency } from "./model";

const SYMBOL: Record<Currency, string> = {
  USD: "$",
  TRY: "₺",
  EUR: "€",
  GBP: "£",
};

export function symbol(currency: Currency) {
  return SYMBOL[currency];
}

export function money(currency: Currency, value: number, digits = 2) {
  const n = Number.isFinite(value) ? value : 0;
  const formatted = n.toLocaleString("en-US", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });
  return SYMBOL[currency] + formatted;
}

export function num(value: number, digits = 2) {
  const n = Number.isFinite(value) ? value : 0;
  return n.toLocaleString("en-US", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });
}

export function signedPct(value: number, digits = 2) {
  if (!Number.isFinite(value)) return "—";
  const sign = value > 0 ? "+" : "";
  return sign + value.toFixed(digits) + "%";
}
