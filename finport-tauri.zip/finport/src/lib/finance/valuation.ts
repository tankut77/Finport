import type { ValuationDraft } from "./model";

export function capmKe(rf: number, beta: number, erp: number) {
  return rf + beta * erp;
}

export function dcfSharePrice(
  fcf0: number,
  g1: number,
  gT: number,
  wacc: number,
  netDebt: number,
  shares: number,
) {
  if (!(wacc > gT) || !(shares > 0)) return 0;
  let pvSum = 0;
  let curFcf = fcf0;
  for (let i = 1; i <= 5; i++) {
    curFcf = curFcf * (1 + g1);
    pvSum += curFcf / Math.pow(1 + wacc, i);
  }
  const tv = (curFcf * (1 + gT)) / (wacc - gT);
  const pvTv = tv / Math.pow(1 + wacc, 5);
  return (pvSum + pvTv - netDebt) / shares;
}

export type DcfRow = {
  year: number;
  growth: number;
  fcf: number;
  df: number;
  pv: number;
};

export type DcfResult = {
  rows: DcfRow[];
  pvFcf: number;
  terminal: number;
  pvTerminal: number;
  enterprise: number;
  equity: number;
  perShare: number;
  waccUsed: number;
  floored: boolean;
};

export function runDcf(draft: ValuationDraft): DcfResult {
  const shares = Math.max(0.0001, draft.shares);
  const g1 = draft.g1 / 100;
  const gT = draft.gT / 100;
  const raw = draft.wacc / 100;
  const floored = raw < gT + 0.005;
  const wacc = Math.max(gT + 0.005, raw);
  const rows: DcfRow[] = [];
  let pvFcf = 0;
  let fcf = draft.fcf;
  for (let year = 1; year <= 5; year++) {
    fcf = fcf * (1 + g1);
    const df = 1 / Math.pow(1 + wacc, year);
    const pv = fcf * df;
    pvFcf += pv;
    rows.push({ year, growth: g1 * 100, fcf, df, pv });
  }
  const terminal = (fcf * (1 + gT)) / (wacc - gT);
  const pvTerminal = terminal / Math.pow(1 + wacc, 5);
  const enterprise = pvFcf + pvTerminal;
  const equity = enterprise - draft.netDebt;
  return {
    rows,
    pvFcf,
    terminal,
    pvTerminal,
    enterprise,
    equity,
    perShare: equity / shares,
    waccUsed: wacc,
    floored,
  };
}

export type Sensitivity = {
  growth: number[];
  rows: { wacc: number; prices: number[] }[];
};

export function sensitivityMatrix(draft: ValuationDraft, dcf: DcfResult): Sensitivity {
  const shares = Math.max(0.0001, draft.shares);
  const g1 = draft.g1 / 100;
  const gT = draft.gT / 100;
  const gSteps = [-0.01, -0.005, 0, 0.005, 0.01];
  const wSteps = [-0.01, -0.005, 0, 0.005, 0.01];
  return {
    growth: gSteps.map((step) => gT + step),
    rows: wSteps.map((step) => {
      const wacc = Math.max(0.01, dcf.waccUsed + step);
      return {
        wacc,
        prices: gSteps.map((gStep) =>
          dcfSharePrice(draft.fcf, g1, gT + gStep, wacc, draft.netDebt, shares),
        ),
      };
    }),
  };
}

export type ValuationResult =
  | { method: "dcf"; perShare: number; dcf: DcfResult; matrix: Sensitivity }
  | { method: "multiples"; perShare: number; pe: number; ev: number; pb: number }
  | {
      method: "ddm";
      perShare: number;
      d1: number;
      ke: number;
      g: number;
      floored: boolean;
    }
  | { method: "nav"; perShare: number; nav: number }
  | { method: "liquidation"; perShare: number; sale: number; claims: number; net: number };

export function valuate(draft: ValuationDraft): ValuationResult {
  const shares = Math.max(0.0001, draft.shares);
  if (draft.method === "dcf") {
    const dcf = runDcf(draft);
    return { method: "dcf", perShare: dcf.perShare, dcf, matrix: sensitivityMatrix(draft, dcf) };
  }
  if (draft.method === "multiples") {
    const pe = draft.eps * draft.pe;
    const ev = (draft.ebitda * draft.evEbitda - draft.multDebt) / shares;
    const pb = draft.bvps * draft.pb;
    return { method: "multiples", perShare: (pe + ev + pb) / 3, pe, ev, pb };
  }
  if (draft.method === "ddm") {
    const g = draft.divG / 100;
    const raw = draft.divKe / 100;
    const floored = raw < g + 0.005;
    const ke = Math.max(g + 0.005, raw);
    const d1 = draft.div0 * (1 + g);
    return { method: "ddm", perShare: d1 / (ke - g), d1, ke, g, floored };
  }
  if (draft.method === "nav") {
    const nav = draft.navAssets - draft.navLiab;
    return { method: "nav", perShare: nav / shares, nav };
  }
  const sale = draft.liqAssets * (1 - draft.liqDisc / 100);
  const claims = draft.liqLiab + draft.liqCost;
  const net = sale - claims;
  return { method: "liquidation", perShare: net / shares, sale, claims, net };
}

export type Signal = {
  upside: number | null;
  label: string;
  tone: "up" | "down" | "warn" | "muted";
};

export function priceSignal(intrinsic: number, market: number): Signal {
  if (!(market > 0)) return { upside: null, label: "—", tone: "muted" };
  if (!(intrinsic > 0)) return { upside: null, label: "Değer negatif", tone: "down" };
  const upside = ((intrinsic - market) / market) * 100;
  if (upside >= 15) return { upside, label: "İskontolu", tone: "up" };
  if (upside <= -15) return { upside, label: "Primli", tone: "down" };
  return { upside, label: "Adil değerde", tone: "warn" };
}
