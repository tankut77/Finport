import { saveTextFile } from "@/lib/platform";
import {
  BOND_TYPES,
  CURRENCIES,
  type BondType,
  type Currency,
  type PortfolioItem,
} from "./model";

const SYMBOL_TO_CCY: Record<string, Currency> = {
  $: "USD",
  USD: "USD",
  "₺": "TRY",
  TRY: "TRY",
  TL: "TRY",
  "€": "EUR",
  EUR: "EUR",
  "£": "GBP",
  GBP: "GBP",
};

export function downloadCsv(filename: string, content: string) {
  // BOM keeps Turkish characters intact when the file is opened in Excel.
  void saveTextFile(filename, "\uFEFF" + content, "text/csv").catch((err) => {
    console.error("CSV kaydedilemedi", err);
  });
}

export function portfolioToCsv(items: PortfolioItem[]) {
  const lines = ["ISIN_Kodu;Tur;Para_Birimi;Adet;Birim_Fiyat;Modifiye_Durasyon;Konveksite"];
  for (const item of items) {
    lines.push(
      [
        item.code,
        item.type,
        item.currency,
        item.qty,
        item.price.toFixed(2),
        item.mod.toFixed(2),
        item.conv.toFixed(2),
      ].join(";"),
    );
  }
  return lines.join("\r\n") + "\r\n";
}

export function portfolioTemplateCsv() {
  return (
    "ISIN_Kodu;Tur;Para_Birimi;Adet;Birim_Fiyat;Modifiye_Durasyon;Konveksite\r\n" +
    "TRT200928T19;fixed;TRY;200;945.20;3.45;15.20\r\n" +
    "US912810TJ79;fixed;USD;100;980.50;7.85;78.40\r\n"
  );
}

function asType(value: string): BondType {
  const v = value.trim().toLowerCase();
  return (BOND_TYPES as readonly string[]).includes(v) ? (v as BondType) : "fixed";
}

function asCurrency(value: string): Currency {
  const key = value.trim().toUpperCase();
  if ((CURRENCIES as readonly string[]).includes(key)) return key as Currency;
  return SYMBOL_TO_CCY[value.trim()] ?? SYMBOL_TO_CCY[key] ?? "USD";
}

export function parsePortfolioCsv(text: string): PortfolioItem[] {
  const clean = text.replace(/^\uFEFF/, "");
  const lines = clean.split(/\r\n|\n/).map((line) => line.trim()).filter(Boolean);
  if (lines.length < 2) return [];
  const delim = lines[0].includes(";") ? ";" : ",";
  const items: PortfolioItem[] = [];
  for (let i = 1; i < lines.length; i++) {
    const cells = lines[i].split(delim).map((cell) => cell.trim());
    if (cells.length < 5 || !cells[0]) continue;
    const qty = Number(cells[3]);
    const price = Number(cells[4]);
    const mod = Number(cells[5]);
    const conv = Number(cells[6]);
    items.push({
      id: crypto.randomUUID(),
      code: cells[0],
      type: asType(cells[1] || "fixed"),
      currency: asCurrency(cells[2] || "USD"),
      qty: Number.isFinite(qty) ? qty : 0,
      price: Number.isFinite(price) ? price : 0,
      mod: Number.isFinite(mod) ? mod : 0,
      conv: Number.isFinite(conv) ? conv : 0,
    });
  }
  return items;
}
