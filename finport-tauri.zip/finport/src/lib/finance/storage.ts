import {
  BOND_TYPES,
  CURRENCIES,
  TABS,
  VAL_CURRENCIES,
  VAL_METHODS,
  type AppState,
  type BondDraft,
  type BondType,
  type Currency,
  type PortfolioItem,
  type TabId,
  type ValCurrency,
  type ValMethod,
  type ValuationDraft,
  defaultAppState,
  defaultBondDraft,
  defaultValuation,
} from "./model";

const KEY = "finport-v1";

function num(value: unknown, fallback: number) {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

function str(value: unknown, fallback: string) {
  return typeof value === "string" ? value : fallback;
}

function oneOf<T extends string>(value: unknown, allowed: readonly T[], fallback: T): T {
  return typeof value === "string" && (allowed as readonly string[]).includes(value)
    ? (value as T)
    : fallback;
}

function mergeBond(raw: unknown): BondDraft {
  const base = defaultBondDraft;
  if (!raw || typeof raw !== "object") return base;
  const o = raw as Record<string, unknown>;
  return {
    code: str(o.code, base.code),
    type: oneOf<BondType>(o.type, BOND_TYPES, base.type),
    currency: oneOf<Currency>(o.currency, CURRENCIES, base.currency),
    face: num(o.face, base.face),
    mat: num(o.mat, base.mat),
    coup: num(o.coup, base.coup),
    freq: num(o.freq, base.freq),
    ytm: num(o.ytm, base.ytm),
    idx: num(o.idx, base.idx),
    inflation: num(o.inflation, base.inflation),
    resetM: num(o.resetM, base.resetM),
    spread: num(o.spread, base.spread),
    qty: num(o.qty, base.qty),
  };
}

function mergeValuation(raw: unknown): ValuationDraft {
  const base = defaultValuation;
  if (!raw || typeof raw !== "object") return base;
  const o = raw as Record<string, unknown>;
  const next = { ...base };
  (Object.keys(base) as (keyof ValuationDraft)[]).forEach((key) => {
    const value = o[key];
    if (key === "ticker") next.ticker = str(value, base.ticker);
    else if (key === "currency") next.currency = oneOf<ValCurrency>(value, VAL_CURRENCIES, base.currency);
    else if (key === "method") next.method = oneOf<ValMethod>(value, VAL_METHODS, base.method);
    else if (typeof value === "number" && Number.isFinite(value)) {
      (next[key] as number) = value;
    }
  });
  return next;
}

function mergePortfolio(raw: unknown): PortfolioItem[] {
  if (!Array.isArray(raw)) return [];
  const items: PortfolioItem[] = [];
  for (const entry of raw) {
    if (!entry || typeof entry !== "object") continue;
    const o = entry as Record<string, unknown>;
    if (typeof o.id !== "string" || typeof o.code !== "string") continue;
    const qty = num(o.qty, NaN);
    const price = num(o.price, NaN);
    const mod = num(o.mod, NaN);
    const conv = num(o.conv, NaN);
    if (![qty, price, mod, conv].every(Number.isFinite)) continue;
    items.push({
      id: o.id,
      code: o.code,
      type: oneOf<BondType>(o.type, BOND_TYPES, "fixed"),
      currency: oneOf<Currency>(o.currency, CURRENCIES, "USD"),
      qty,
      price,
      mod,
      conv,
    });
  }
  return items;
}

export function loadAppState(): AppState | null {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const data = JSON.parse(raw) as Record<string, unknown>;
    return {
      tab: oneOf<TabId>(data.tab, TABS, defaultAppState.tab),
      bond: mergeBond(data.bond),
      dyBps: Math.min(1000, Math.max(-1000, num(data.dyBps, defaultAppState.dyBps))),
      portfolio: mergePortfolio(data.portfolio),
      valuation: mergeValuation(data.valuation),
    };
  } catch {
    return null;
  }
}

export function saveAppState(state: AppState) {
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch {
    /* private mode or full storage — the session still works */
  }
}
