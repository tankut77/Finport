export const CURRENCIES = ["USD", "TRY", "EUR", "GBP"] as const;
export type Currency = (typeof CURRENCIES)[number];

export const BOND_TYPES = ["fixed", "zero", "frn", "tufex"] as const;
export type BondType = (typeof BOND_TYPES)[number];

export const BOND_TYPE_LABEL: Record<BondType, string> = {
  fixed: "Sabit kupon",
  zero: "İskontolu",
  frn: "Değişken (FRN)",
  tufex: "TÜFEX / TIPS",
};

export const VAL_METHODS = ["dcf", "multiples", "ddm", "nav", "liquidation"] as const;
export type ValMethod = (typeof VAL_METHODS)[number];

export const VAL_CURRENCIES = ["USD", "TRY", "EUR"] as const;
export type ValCurrency = (typeof VAL_CURRENCIES)[number];

export const TABS = ["portal", "bonds", "valuation", "guide"] as const;
export type TabId = (typeof TABS)[number];

export type BondDraft = {
  code: string;
  type: BondType;
  currency: Currency;
  face: number;
  mat: number;
  coup: number;
  freq: number;
  ytm: number;
  idx: number;
  inflation: number;
  resetM: number;
  spread: number;
  qty: number;
};

export type PortfolioItem = {
  id: string;
  code: string;
  type: BondType;
  currency: Currency;
  qty: number;
  price: number;
  mod: number;
  conv: number;
};

export type ValuationDraft = {
  ticker: string;
  currency: ValCurrency;
  method: ValMethod;
  marketP: number;
  shares: number;
  rf: number;
  beta: number;
  erp: number;
  fcf: number;
  netDebt: number;
  g1: number;
  gT: number;
  wacc: number;
  eps: number;
  pe: number;
  ebitda: number;
  evEbitda: number;
  bvps: number;
  pb: number;
  multDebt: number;
  div0: number;
  divG: number;
  divKe: number;
  navAssets: number;
  navLiab: number;
  liqAssets: number;
  liqDisc: number;
  liqLiab: number;
  liqCost: number;
};

export const defaultBondDraft: BondDraft = {
  code: "TRT200928T19",
  type: "fixed",
  currency: "USD",
  face: 1000,
  mat: 10,
  coup: 6.5,
  freq: 2,
  ytm: 6,
  idx: 1.35,
  inflation: 25,
  resetM: 3,
  spread: 1.25,
  qty: 100,
};

export const defaultValuation: ValuationDraft = {
  ticker: "THYAO / AAPL",
  currency: "USD",
  method: "dcf",
  marketP: 150,
  shares: 100,
  rf: 4.2,
  beta: 1.1,
  erp: 5,
  fcf: 1200,
  netDebt: 1500,
  g1: 12,
  gT: 2.5,
  wacc: 9,
  eps: 9.5,
  pe: 16,
  ebitda: 1800,
  evEbitda: 10.5,
  bvps: 85,
  pb: 2,
  multDebt: 1500,
  div0: 6,
  divG: 5,
  divKe: 9.7,
  navAssets: 32000,
  navLiab: 14500,
  liqAssets: 32000,
  liqDisc: 25,
  liqLiab: 14500,
  liqCost: 800,
};

export type AppState = {
  tab: TabId;
  bond: BondDraft;
  dyBps: number;
  portfolio: PortfolioItem[];
  valuation: ValuationDraft;
};

export const defaultAppState: AppState = {
  tab: "bonds",
  bond: defaultBondDraft,
  dyBps: -50,
  portfolio: [],
  valuation: defaultValuation,
};
