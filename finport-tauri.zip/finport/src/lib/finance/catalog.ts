export type ToolLink = {
  name: string;
  href: string;
  detail: string;
};

export type ToolGroup = {
  title: string;
  blurb: string;
  links: ToolLink[];
};

export const TOOL_GROUPS: ToolGroup[] = [
  {
    title: "Resmi ve makro veriler",
    blurb: "Faiz, enflasyon ve resmi şirket bildirimleri.",
    links: [
      {
        name: "SEC EDGAR",
        href: "https://www.sec.gov/edgar/search/",
        detail: "10-K ve 10-Q resmi şirket bildirimleri.",
      },
      {
        name: "FRED",
        href: "https://fred.stlouisfed.org",
        detail: "Faiz, enflasyon, likidite ve makro seriler.",
      },
      {
        name: "CME FedWatch",
        href: "https://www.cmegroup.com/markets/interest-rates/cme-fedwatch-tool.html",
        detail: "Fed faiz beklentileri ve vadeli olasılıklar.",
      },
      {
        name: "BIS",
        href: "https://www.bis.org",
        detail: "Küresel bankacılık ve merkez bankası raporları.",
      },
    ],
  },
  {
    title: "Temel analiz ve bilanço",
    blurb: "Serbest nakit, çarpan ve kâr marjı kaynakları.",
    links: [
      {
        name: "Macrotrends",
        href: "https://www.macrotrends.net",
        detail: "Uzun dönem finansallar, çarpanlar ve marjlar.",
      },
      {
        name: "Finviz",
        href: "https://finviz.com",
        detail: "Hisse tarayıcı ve piyasa ısı haritaları.",
      },
      {
        name: "Roic.ai",
        href: "https://roic.ai",
        detail: "ROIC ve serbest nakit akışı.",
      },
      {
        name: "StockAnalysis",
        href: "https://stockanalysis.com",
        detail: "Şirket finansalları ve temettü takibi.",
      },
    ],
  },
  {
    title: "ETF ve portföy simülasyonu",
    blurb: "Backtest, UCITS fon ve gider oranı.",
    links: [
      {
        name: "Portfolio Visualizer",
        href: "https://www.portfoliovisualizer.com",
        detail: "Backtest, korelasyon ve faktör analizi.",
      },
      {
        name: "Curvo",
        href: "https://curvo.eu",
        detail: "Avrupa UCITS portföy simülasyonu ve DCA.",
      },
      {
        name: "JustETF",
        href: "https://www.justetf.com",
        detail: "UCITS tarayıcı ve gider oranı karşılaştırması.",
      },
      {
        name: "ETF Database",
        href: "https://etfdb.com",
        detail: "Küresel ETF veritabanı ve sınıflandırma.",
      },
    ],
  },
  {
    title: "Kurumsal takip ve teknik",
    blurb: "13F, grafik ve sektör rotasyonu.",
    links: [
      {
        name: "Dataroma",
        href: "https://www.dataroma.com",
        detail: "Süper yatırımcıların 13F hareketleri.",
      },
      {
        name: "TradingView",
        href: "https://www.tradingview.com",
        detail: "Teknik grafikler ve gösterge panelleri.",
      },
      {
        name: "StockCharts",
        href: "https://stockcharts.com",
        detail: "Sektör rotasyonu ve RRG grafikleri.",
      },
      {
        name: "Investopedia",
        href: "https://www.investopedia.com",
        detail: "Terimler ve gösterge açıklamaları.",
      },
    ],
  },
  {
    title: "Eğitim ve bültenler",
    blurb: "Değerleme, faktör ve makro okuma listesi.",
    links: [
      {
        name: "Aswath Damodaran",
        href: "https://www.youtube.com/@AswathDamodaranonValuation",
        detail: "DCF ve kurumsal finans dersleri.",
      },
      {
        name: "Ben Felix",
        href: "https://www.youtube.com/@BenFelixCSI",
        detail: "Faktör yatırımı ve rasyonel portföy.",
      },
      {
        name: "Howard Marks",
        href: "https://www.oaktreecapital.com/insights/memos",
        detail: "Piyasa döngüleri ve risk bültenleri.",
      },
      {
        name: "Lyn Alden",
        href: "https://www.lynalden.com",
        detail: "Makro likidite ve para dinamikleri.",
      },
    ],
  },
];
