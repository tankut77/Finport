import type { BondDraft, BondType } from "./model";

export type BondCalcInput = {
  type: BondType;
  face: number;
  mat: number;
  coup: number;
  freq: number;
  ytm: number;
  idx: number;
  resetM: number;
  spread: number;
};

export type CashFlow = {
  t: number;
  yr: number;
  cp: number;
  pr: number;
  cf: number;
  df: number;
  pv: number;
  w: number;
};

export type BondMetrics = {
  price: number;
  mac: number;
  mod: number;
  conv: number;
  flows: CashFlow[];
};

export function toCalc(draft: BondDraft): BondCalcInput {
  return {
    type: draft.type,
    face: draft.face,
    mat: draft.mat,
    coup: draft.coup,
    freq: draft.freq,
    ytm: draft.ytm,
    idx: draft.idx,
    resetM: draft.resetM,
    spread: draft.spread,
  };
}

export function computeBondMetrics(p: BondCalcInput): BondMetrics {
  const y = Math.max(0.0001, p.ytm / 100);
  const m = Math.max(1, p.freq || 1);
  const mat = Math.max(0.25, p.mat);
  const face = p.face;

  if (p.type === "zero") {
    const price = face / Math.pow(1 + y, mat);
    const mac = mat;
    const mod = mat / (1 + y);
    const conv = (mat * (mat + 1)) / Math.pow(1 + y, 2);
    const df = 1 / Math.pow(1 + y, mat);
    return {
      price,
      mac,
      mod,
      conv,
      flows: [{ t: 1, yr: mat, cp: 0, pr: face, cf: face, df, pv: price, w: 100 }],
    };
  }

  if (p.type === "frn") {
    const rTime = Math.max(1, p.resetM) / 12;
    const cp = face * ((y + p.spread / 100) / m);
    const df = 1 / Math.pow(1 + y / m, rTime * m);
    const price = (face + cp) * df;
    const mac = rTime;
    const mod = rTime / (1 + y / m);
    const conv = (rTime * (rTime + 1 / m)) / Math.pow(1 + y / m, 2);
    return {
      price,
      mac,
      mod,
      conv,
      flows: [{ t: 1, yr: rTime, cp, pr: face, cf: face + cp, df, pv: price, w: 100 }],
    };
  }

  const n = Math.max(1, Math.round(mat * m));
  const adjFace = p.type === "tufex" ? face * p.idx : face;
  const cpVal = adjFace * (p.coup / 100 / m);
  let pvSum = 0;
  let wTime = 0;
  let convSum = 0;
  const flows: CashFlow[] = [];

  for (let i = 1; i <= n; i++) {
    const yr = i / m;
    const pr = i === n ? adjFace : 0;
    const cf = cpVal + pr;
    const df = 1 / Math.pow(1 + y / m, i);
    const pv = cf * df;
    pvSum += pv;
    wTime += yr * pv;
    convSum += (i * (i + 1) * cf) / (Math.pow(1 + y / m, i + 2) * m * m);
    flows.push({ t: i, yr, cp: cpVal, pr, cf, df, pv, w: 0 });
  }

  const price = pvSum;
  const mac = price > 0 ? wTime / price : 0;
  const mod = mac / (1 + y / m);
  const conv = price > 0 ? convSum / price : 0;
  for (const flow of flows) flow.w = price > 0 ? (flow.pv / price) * 100 : 0;
  return { price, mac, mod, conv, flows };
}

export function taylorShock(price: number, mod: number, conv: number, dyBps: number) {
  const dy = dyBps / 10000;
  const pct = -mod * dy + 0.5 * conv * dy * dy;
  return {
    dy,
    pct,
    durationOnly: price * (1 - mod * dy),
    taylor: price * (1 + pct),
  };
}

export type CurvePoint = { ytm: number; price: number; tangent: number };

export function priceYieldCurve(input: BondCalcInput, price: number, mod: number): CurvePoint[] {
  const yMin = Math.max(0.25, input.ytm - 4);
  const yMax = input.ytm + 4;
  const start = Math.round(yMin * 4);
  const end = Math.round(yMax * 4);
  const points: CurvePoint[] = [];
  for (let i = start; i <= end; i++) {
    const ytm = i / 4;
    const next = computeBondMetrics({ ...input, ytm }).price;
    const tangent = price * (1 - mod * ((ytm - input.ytm) / 100));
    points.push({ ytm, price: next, tangent });
  }
  return points;
}

export function nominalFromReal(realPct: number, inflationPct: number) {
  return ((1 + realPct / 100) * (1 + inflationPct / 100) - 1) * 100;
}
