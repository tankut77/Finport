import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Field, NumInput, Panel, SelectInput, Stat, TextInput } from "@/components/finport/ui";
import { downloadCsv } from "@/lib/finance/csv";
import { money, signedPct } from "@/lib/finance/format";
import { VAL_CURRENCIES, type ValMethod, type ValuationDraft } from "@/lib/finance/model";
import { capmKe, priceSignal, valuate } from "@/lib/finance/valuation";

const METHODS: { value: ValMethod; label: string }[] = [
  { value: "dcf", label: "İndirgenmiş nakit akımları (DCF)" },
  { value: "multiples", label: "Çarpan analizi (F/K, FD/FAVÖK, PD/DD)" },
  { value: "ddm", label: "Temettü iskontosu (Gordon)" },
  { value: "nav", label: "Net aktif değeri (NAV)" },
  { value: "liquidation", label: "Tasfiye değeri" },
];

export function ValuationView({
  draft,
  onDraft,
}: {
  draft: ValuationDraft;
  onDraft: (draft: ValuationDraft) => void;
}) {
  const set = <K extends keyof ValuationDraft>(key: K, value: ValuationDraft[K]) =>
    onDraft({ ...draft, [key]: value });
  const ke = capmKe(draft.rf, draft.beta, draft.erp);
  const result = valuate(draft);
  const signal = priceSignal(result.perShare, draft.marketP);
  const tone = signal.tone === "muted" ? "ink" : signal.tone;

  function applyCapm() {
    const next = Number(ke.toFixed(2));
    onDraft({ ...draft, wacc: next, divKe: next });
  }

  return (
    <div className="grid min-w-0 grid-cols-1 items-start gap-5 lg:grid-cols-[22rem_minmax(0,1fr)]">
      <div className="lg:sticky lg:top-24 lg:max-h-[calc(100dvh-7rem)] lg:overflow-y-auto lg:pr-1">
        <Panel title="Değerleme girdileri">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Şirket kodu">
              <TextInput value={draft.ticker} onChange={(ticker) => set("ticker", ticker)} />
            </Field>
            <Field label="Para birimi">
              <SelectInput
                value={draft.currency}
                onChange={(currency) => set("currency", currency)}
                options={VAL_CURRENCIES.map((currency) => ({ value: currency, label: currency }))}
              />
            </Field>
          </div>
          <div className="mt-3">
            <Field label="Yöntem">
              <SelectInput
                value={draft.method}
                onChange={(method) => set("method", method)}
                options={METHODS}
              />
            </Field>
          </div>
          <div className="mt-3 grid grid-cols-2 gap-3">
            <Field label="Güncel hisse fiyatı">
              <NumInput value={draft.marketP} step={1} onChange={(marketP) => set("marketP", marketP)} />
            </Field>
            <Field label="Pay adedi (milyon)">
              <NumInput value={draft.shares} step={1} min={0.0001} onChange={(shares) => set("shares", shares)} />
            </Field>
          </div>
          <p className="mt-2 text-xs text-faint">
            Şirket tutarları pay adediyle aynı birimdedir. Pay milyon ise FCF ve borç da milyondur.
          </p>

          <div className="mt-4 rounded-lg border border-line bg-bg p-3">
            <div className="mb-2 flex items-center justify-between gap-2">
              <p className="text-xs font-semibold text-primary">CAPM</p>
              <Button onClick={applyCapm}>İskontoya aktar</Button>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <Field label="Rf %">
                <NumInput value={draft.rf} step={0.1} onChange={(rf) => set("rf", rf)} />
              </Field>
              <Field label="Beta">
                <NumInput value={draft.beta} step={0.05} onChange={(beta) => set("beta", beta)} />
              </Field>
              <Field label="ERP %">
                <NumInput value={draft.erp} step={0.1} onChange={(erp) => set("erp", erp)} />
              </Field>
            </div>
            <p className="mt-2 text-xs text-muted">
              Özsermaye maliyeti <span className="font-mono font-semibold text-up">{ke.toFixed(2)}%</span>
              <span className="text-faint"> · Rf + β × ERP</span>
            </p>
          </div>

          {draft.method === "dcf" ? (
            <div className="mt-3 space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <Field label="Başlangıç FCF">
                  <NumInput value={draft.fcf} onChange={(fcf) => set("fcf", fcf)} />
                </Field>
                <Field label="Net borç">
                  <NumInput value={draft.netDebt} onChange={(netDebt) => set("netDebt", netDebt)} />
                </Field>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Field label="1–5. yıl büyüme %">
                  <NumInput value={draft.g1} step={0.5} onChange={(g1) => set("g1", g1)} />
                </Field>
                <Field label="Sonsuz büyüme g %">
                  <NumInput value={draft.gT} step={0.1} onChange={(gT) => set("gT", gT)} />
                </Field>
              </div>
              <Field label="İskonto oranı WACC %">
                <NumInput value={draft.wacc} step={0.1} onChange={(wacc) => set("wacc", wacc)} />
              </Field>
            </div>
          ) : null}

          {draft.method === "multiples" ? (
            <div className="mt-3 space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <Field label="Hisse başı kâr">
                  <NumInput value={draft.eps} step={0.1} onChange={(eps) => set("eps", eps)} />
                </Field>
                <Field label="Emsal F/K">
                  <NumInput value={draft.pe} step={0.5} onChange={(pe) => set("pe", pe)} />
                </Field>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Field label="FAVÖK">
                  <NumInput value={draft.ebitda} onChange={(ebitda) => set("ebitda", ebitda)} />
                </Field>
                <Field label="FD/FAVÖK">
                  <NumInput value={draft.evEbitda} step={0.5} onChange={(evEbitda) => set("evEbitda", evEbitda)} />
                </Field>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Hisse başı defter">
                  <NumInput value={draft.bvps} onChange={(bvps) => set("bvps", bvps)} />
                </Field>
                <Field label="Emsal PD/DD">
                  <NumInput value={draft.pb} step={0.1} onChange={(pb) => set("pb", pb)} />
                </Field>
              </div>
              <Field label="Net borç">
                <NumInput value={draft.multDebt} onChange={(multDebt) => set("multDebt", multDebt)} />
              </Field>
            </div>
          ) : null}

          {draft.method === "ddm" ? (
            <div className="mt-3 space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <Field label="Son temettü D0">
                  <NumInput value={draft.div0} step={0.1} onChange={(div0) => set("div0", div0)} />
                </Field>
                <Field label="Temettü büyümesi %">
                  <NumInput value={draft.divG} step={0.2} onChange={(divG) => set("divG", divG)} />
                </Field>
              </div>
              <Field label="Özsermaye maliyeti Ke %">
                <NumInput value={draft.divKe} step={0.1} onChange={(divKe) => set("divKe", divKe)} />
              </Field>
            </div>
          ) : null}

          {draft.method === "nav" ? (
            <div className="mt-3 grid grid-cols-2 gap-3">
              <Field label="Piyasa değerli aktifler">
                <NumInput value={draft.navAssets} onChange={(navAssets) => set("navAssets", navAssets)} />
              </Field>
              <Field label="Yükümlülükler">
                <NumInput value={draft.navLiab} onChange={(navLiab) => set("navLiab", navLiab)} />
              </Field>
            </div>
          ) : null}

          {draft.method === "liquidation" ? (
            <div className="mt-3 space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <Field label="Toplam aktifler">
                  <NumInput value={draft.liqAssets} onChange={(liqAssets) => set("liqAssets", liqAssets)} />
                </Field>
                <Field label="Acil satış iskontosu %">
                  <NumInput value={draft.liqDisc} step={1} onChange={(liqDisc) => set("liqDisc", liqDisc)} />
                </Field>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Toplam borç">
                  <NumInput value={draft.liqLiab} onChange={(liqLiab) => set("liqLiab", liqLiab)} />
                </Field>
                <Field label="Tasfiye gideri">
                  <NumInput value={draft.liqCost} onChange={(liqCost) => set("liqCost", liqCost)} />
                </Field>
              </div>
            </div>
          ) : null}
        </Panel>
      </div>

      <div className="min-w-0 space-y-4">
        <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
          <Stat
            label="Hisse başı içsel değer"
            value={money(draft.currency, result.perShare)}
            hint={draft.ticker || "Model hedefi"}
            tone="up"
          />
          <Stat
            label="Piyasa fiyatı"
            value={money(draft.currency, draft.marketP)}
            hint={`Piyasa değeri ${money(draft.currency, draft.marketP * Math.max(draft.shares, 0), 0)}`}
            tone="primary"
          />
          <Stat
            label="Güvenlik marjı"
            value={signal.upside === null ? "—" : signedPct(signal.upside)}
            hint="(İçsel − piyasa) / piyasa"
            tone={tone}
          />
          <Stat label="Sinyal" value={signal.label} hint="Eşik ±%15" tone={tone} />
        </div>

        {result.method === "dcf" ? (
          <>
            {result.dcf.floored ? (
              <p className="rounded-lg border border-warn/40 bg-warn/10 px-3 py-2 text-sm text-warn">
                WACC sonsuz büyümenin altındaydı. Hesap %{ (result.dcf.waccUsed * 100).toFixed(2) } ile
                yapıldı.
              </p>
            ) : null}
            <Panel
              title="Beş yıllık nakit akışı"
              action={
                <Button
                  onClick={() => {
                    const lines = ["Yil;Buyume_Yuzde;Tahmini_FCF;Iskonto_DF;Bugunku_Deger_PV"];
                    for (const row of result.dcf.rows) {
                      lines.push(
                        [row.year, row.growth.toFixed(1), row.fcf.toFixed(2), row.df.toFixed(4), row.pv.toFixed(2)].join(
                          ";",
                        ),
                      );
                    }
                    downloadCsv("DCF_Sirket_Degerleme.csv", lines.join("\r\n") + "\r\n");
                  }}
                >
                  <Download className="size-4" />
                  CSV
                </Button>
              }
            >
              <div className="overflow-x-auto rounded-lg border border-line">
                <table className="w-full min-w-[36rem] text-left text-sm">
                  <thead className="bg-bg text-xs uppercase tracking-wide text-muted">
                    <tr>
                      {["Yıl", "Büyüme", "Tahmini FCF", "İskonto", "Bugünkü değer"].map((head) => (
                        <th key={head} className="px-3 py-2 font-medium">
                          {head}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {result.dcf.rows.map((row) => (
                      <tr key={row.year} className="border-t border-line">
                        <td className="px-3 py-2 font-mono font-semibold text-primary">Yıl {row.year}</td>
                        <td className="px-3 py-2 font-mono tabular-nums">%{row.growth.toFixed(1)}</td>
                        <td className="px-3 py-2 font-mono tabular-nums">
                          {money(draft.currency, row.fcf, 0)}
                        </td>
                        <td className="px-3 py-2 font-mono tabular-nums">{row.df.toFixed(4)}</td>
                        <td className="px-3 py-2 font-mono font-semibold tabular-nums text-up">
                          {money(draft.currency, row.pv, 0)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="mt-3 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                <Stat label="Nakitlerin BD" value={money(draft.currency, result.dcf.pvFcf, 0)} tone="primary" />
                <Stat label="Uç değerin BD" value={money(draft.currency, result.dcf.pvTerminal, 0)} tone="iris" />
                <Stat label="Firma değeri" value={money(draft.currency, result.dcf.enterprise, 0)} tone="warn" />
                <Stat label="Özkaynak değeri" value={money(draft.currency, result.dcf.equity, 0)} tone="up" />
              </div>
            </Panel>
            <Panel title="Hassasiyet: WACC ve sonsuz büyüme">
              <p className="mb-3 text-xs text-faint">
                Ortadaki hücre baz senaryodur. Satırlar iskontoyu, sütunlar sonsuz büyümeyi ±1 puan kaydırır.
              </p>
              <div className="overflow-x-auto rounded-lg border border-line">
                <table className="w-full min-w-[40rem] text-left text-sm">
                  <thead className="bg-bg text-xs text-muted">
                    <tr>
                      <th className="px-3 py-2 font-medium">WACC \ g</th>
                      {result.matrix.growth.map((growth) => (
                        <th key={growth} className="px-3 py-2 font-medium">
                          g %{(growth * 100).toFixed(1)}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {result.matrix.rows.map((row, rowIndex) => (
                      <tr key={row.wacc} className="border-t border-line">
                        <td className="px-3 py-2 font-mono font-semibold text-warn">
                          %{(row.wacc * 100).toFixed(1)}
                        </td>
                        {row.prices.map((price, colIndex) => {
                          const center = rowIndex === 2 && colIndex === 2;
                          return (
                            <td
                              key={`${row.wacc}-${colIndex}`}
                              className={`px-3 py-2 font-mono tabular-nums ${center ? "bg-primary/15 font-semibold text-up" : ""}`}
                            >
                              {price > 0 ? money(draft.currency, price) : "—"}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Panel>
          </>
        ) : null}

        {result.method === "multiples" ? (
          <Panel title="Üç çarpan, tek ortalama">
            <p className="mb-3 text-sm text-muted">
              Üstteki içsel değer bu üç hedefin aritmetik ortalamasıdır. FD/FAVÖK satırı net borcu düşer.
            </p>
            <div className="grid gap-3 md:grid-cols-3">
              <Stat label="F/K hedefi" value={money(draft.currency, result.pe)} hint="EPS × sektör F/K" tone="primary" />
              <Stat
                label="FD/FAVÖK hedefi"
                value={money(draft.currency, result.ev)}
                hint="(FAVÖK × çarpan − net borç) / pay"
                tone="warn"
              />
              <Stat label="PD/DD hedefi" value={money(draft.currency, result.pb)} hint="Defter × emsal PD/DD" tone="iris" />
            </div>
          </Panel>
        ) : null}

        {result.method === "ddm" ? (
          <Panel title="Gordon büyüme modeli">
            <div className="grid gap-3 sm:grid-cols-3">
              <Stat label="Gelecek temettü D1" value={money(draft.currency, result.d1)} />
              <Stat label="Kullanılan Ke" value={`%${(result.ke * 100).toFixed(2)}`} tone="warn" />
              <Stat label="Büyüme g" value={`%${(result.g * 100).toFixed(2)}`} tone="primary" />
            </div>
            {result.floored ? (
              <p className="mt-3 text-sm text-warn">Ke, büyümenin altında olduğu için yukarı çekildi.</p>
            ) : null}
            <p className="mt-3 font-mono text-sm text-muted">Değer = D1 / (Ke − g)</p>
          </Panel>
        ) : null}

        {result.method === "nav" ? (
          <Panel title="Net aktif değeri">
            <div className="grid gap-3 sm:grid-cols-2">
              <Stat label="NAV" value={money(draft.currency, result.nav, 0)} hint="Aktifler − yükümlülükler" />
              <Stat label="Hisse başı NAV" value={money(draft.currency, result.perShare)} tone="up" />
            </div>
          </Panel>
        ) : null}

        {result.method === "liquidation" ? (
          <Panel title="Tasfiye değeri">
            <div className="grid gap-3 sm:grid-cols-3">
              <Stat label="İskontolu satış" value={money(draft.currency, result.sale, 0)} tone="warn" />
              <Stat label="Borç ve gider" value={money(draft.currency, result.claims, 0)} tone="down" />
              <Stat label="Net tasfiye" value={money(draft.currency, result.net, 0)} tone="up" />
            </div>
          </Panel>
        ) : null}
      </div>
    </div>
  );
}
