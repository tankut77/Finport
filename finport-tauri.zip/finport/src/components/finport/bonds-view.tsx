import { useRef, useState } from "react";
import { Download, Plus, Trash2, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Field, NumInput, Panel, SelectInput, Stat, TextInput, controlClass } from "@/components/finport/ui";
import { YieldChart } from "@/components/finport/yield-chart";
import {
  computeBondMetrics,
  nominalFromReal,
  priceYieldCurve,
  taylorShock,
  toCalc,
} from "@/lib/finance/bonds";
import {
  downloadCsv,
  parsePortfolioCsv,
  portfolioTemplateCsv,
  portfolioToCsv,
} from "@/lib/finance/csv";
import { money, num } from "@/lib/finance/format";
import {
  BOND_TYPE_LABEL,
  CURRENCIES,
  type BondDraft,
  type BondType,
  type Currency,
  type PortfolioItem,
} from "@/lib/finance/model";

const TYPE_OPTIONS: { value: BondType; label: string }[] = [
  { value: "fixed", label: "Sabit kuponlu tahvil" },
  { value: "zero", label: "İskontolu tahvil / bono" },
  { value: "frn", label: "Değişken faizli tahvil (FRN)" },
  { value: "tufex", label: "TÜFEX / enflasyona endeksli" },
];

const FREQ_OPTIONS = [
  { value: 1, label: "Yılda 1 kez" },
  { value: 2, label: "Yılda 2 kez" },
  { value: 4, label: "Yılda 4 kez" },
  { value: 12, label: "Aylık" },
];

const BPS = [-200, -100, 0, 100, 200];

function changeTone(next: number, base: number) {
  const diff = next - base;
  const pct = base !== 0 ? (diff / base) * 100 : 0;
  return { diff, pct, up: diff >= 0 };
}

export function BondsView({
  draft,
  onDraft,
  dyBps,
  onDy,
  portfolio,
  onPortfolio,
}: {
  draft: BondDraft;
  onDraft: (draft: BondDraft) => void;
  dyBps: number;
  onDy: (bps: number) => void;
  portfolio: PortfolioItem[];
  onPortfolio: (items: PortfolioItem[]) => void;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [confirmClear, setConfirmClear] = useState(false);
  const set = <K extends keyof BondDraft>(key: K, value: BondDraft[K]) =>
    onDraft({ ...draft, [key]: value });

  const calc = toCalc(draft);
  const base = computeBondMetrics(calc);
  const newYtm = Math.max(0.05, draft.ytm + dyBps / 100);
  const exact = computeBondMetrics({ ...calc, ytm: newYtm });
  const shock = taylorShock(base.price, base.mod, base.conv, dyBps);
  const curve = priceYieldCurve(calc, base.price, base.mod);
  const parity = draft.face !== 0 ? (base.price / draft.face) * 100 : 0;
  const nominal =
    draft.type === "tufex" ? nominalFromReal(draft.ytm, draft.inflation) : null;

  const groups = new Map<Currency, PortfolioItem[]>();
  for (const item of portfolio) {
    const list = groups.get(item.currency) ?? [];
    list.push(item);
    groups.set(item.currency, list);
  }

  function addToPortfolio() {
    const metrics = computeBondMetrics(toCalc(draft));
    onPortfolio([
      ...portfolio,
      {
        id: crypto.randomUUID(),
        code: draft.code.trim() || "TAHVIL",
        type: draft.type,
        currency: draft.currency,
        qty: draft.qty,
        price: metrics.price,
        mod: metrics.mod,
        conv: metrics.conv,
      },
    ]);
    setNotice("Tahvil portföye eklendi.");
    setConfirmClear(false);
  }

  function onImport(file: File) {
    const reader = new FileReader();
    reader.onload = () => {
      const text = String(reader.result ?? "");
      const items = parsePortfolioCsv(text);
      if (!items.length) {
        setNotice("Dosyada okunabilir satır yok. Şablondaki sütun sırasını kullanın.");
        return;
      }
      onPortfolio([...portfolio, ...items]);
      setNotice(`${items.length} tahvil portföye eklendi.`);
    };
    reader.readAsText(file, "UTF-8");
  }

  return (
    <div className="grid min-w-0 grid-cols-1 items-start gap-5 lg:grid-cols-[22rem_minmax(0,1fr)]">
      <div className="lg:sticky lg:top-24 lg:max-h-[calc(100dvh-7rem)] lg:overflow-y-auto lg:pr-1">
        <Panel title="Tahvil parametreleri">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Tahvil / ISIN">
              <TextInput value={draft.code} onChange={(code) => set("code", code)} />
            </Field>
            <Field label="Para birimi">
              <SelectInput
                value={draft.currency}
                onChange={(currency) => set("currency", currency)}
                options={CURRENCIES.map((currency) => ({ value: currency, label: currency }))}
              />
            </Field>
          </div>
          <div className="mt-3">
            <Field label="Tahvil türü">
              <SelectInput
                value={draft.type}
                onChange={(type) => set("type", type)}
                options={TYPE_OPTIONS}
              />
            </Field>
          </div>
          <div className="mt-3 grid grid-cols-2 gap-3">
            <Field label="Nominal değer">
              <NumInput value={draft.face} step={100} onChange={(face) => set("face", face)} />
            </Field>
            <Field label="Vadeye kalan (yıl)">
              <NumInput value={draft.mat} step={0.25} min={0.25} onChange={(mat) => set("mat", mat)} />
            </Field>
          </div>
          {draft.type !== "zero" ? (
            <div className="mt-3 grid grid-cols-2 gap-3">
              <Field label="Yıllık kupon (%)">
                <NumInput value={draft.coup} step={0.1} onChange={(coup) => set("coup", coup)} />
              </Field>
              <Field label="Kupon sıklığı">
                <SelectInput
                  value={draft.freq}
                  onChange={(freq) => set("freq", freq)}
                  options={FREQ_OPTIONS}
                />
              </Field>
            </div>
          ) : null}
          {draft.type === "tufex" ? (
            <div className="mt-3 rounded-lg border border-line bg-bg p-3">
              <p className="mb-2 text-xs font-semibold text-primary">Endeksleme</p>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Endeks katsayısı">
                  <NumInput value={draft.idx} step={0.01} onChange={(idx) => set("idx", idx)} />
                </Field>
                <Field label="Beklenen TÜFE (%)">
                  <NumInput
                    value={draft.inflation}
                    step={0.5}
                    onChange={(inflation) => set("inflation", inflation)}
                  />
                </Field>
              </div>
              <p className="mt-2 text-xs text-faint">
                Fiyat reel getiri ve endeks katsayısıyla kurulur. Fisher yaklaşık nominal getiri{" "}
                <span className="font-mono text-ink">{nominal?.toFixed(2)}%</span>.
              </p>
            </div>
          ) : null}
          {draft.type === "frn" ? (
            <div className="mt-3 rounded-lg border border-line bg-bg p-3">
              <p className="mb-2 text-xs font-semibold text-warn">Değişken kupon</p>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Sonraki kupona (ay)">
                  <NumInput
                    value={draft.resetM}
                    min={1}
                    max={12}
                    onChange={(resetM) => set("resetM", resetM)}
                  />
                </Field>
                <Field label="Spread (%)">
                  <NumInput
                    value={draft.spread}
                    step={0.1}
                    onChange={(spread) => set("spread", spread)}
                  />
                </Field>
              </div>
            </div>
          ) : null}

          <div className="mt-4 border-t border-line pt-4">
            <div className="mb-2 flex items-center justify-between text-xs text-muted">
              <span>{draft.type === "tufex" ? "Reel piyasa getirisi" : "Piyasa getirisi (YTM)"}</span>
              <span className="font-mono font-semibold text-primary">{draft.ytm.toFixed(2)}%</span>
            </div>
            <div className="flex items-center gap-3">
              <input
                className="h-11 min-w-0 flex-1 accent-primary"
                type="range"
                min={0.25}
                max={65}
                step={0.05}
                value={Math.min(65, Math.max(0.25, draft.ytm))}
                onChange={(event) => set("ytm", Number(event.target.value))}
                aria-label="Piyasa getirisi"
              />
              <input
                className={`${controlClass} w-24 font-mono tabular-nums`}
                type="number"
                step={0.05}
                value={draft.ytm}
                onChange={(event) => {
                  const next = event.target.valueAsNumber;
                  if (Number.isFinite(next)) set("ytm", next);
                }}
              />
            </div>
          </div>

          <div className="mt-4">
            <div className="mb-2 flex items-center justify-between text-xs text-muted">
              <span>Faiz değişimi</span>
              <span className="font-mono font-semibold text-up">
                {dyBps >= 0 ? "+" : ""}
                {dyBps} bps ({dyBps >= 0 ? "+" : ""}
                {(dyBps / 100).toFixed(2)}%)
              </span>
            </div>
            <input
              className="h-11 w-full accent-primary"
              type="range"
              min={-1000}
              max={1000}
              step={25}
              value={dyBps}
              onChange={(event) => onDy(Number(event.target.value))}
              aria-label="Faiz değişimi baz puan"
            />
            <div className="mt-2 flex flex-wrap gap-2">
              {BPS.map((bps) => (
                <Button key={bps} variant={bps === dyBps ? "primary" : "ghost"} onClick={() => onDy(bps)}>
                  {bps > 0 ? "+" : ""}
                  {bps} bps
                </Button>
              ))}
            </div>
          </div>

          <div className="mt-4 flex items-end gap-3 border-t border-line pt-4">
            <div className="w-28">
              <Field label="Adet">
                <NumInput value={draft.qty} step={1} onChange={(qty) => set("qty", qty)} />
              </Field>
            </div>
            <Button className="flex-1" variant="primary" onClick={addToPortfolio}>
              <Plus className="size-4" />
              Portföye ekle
            </Button>
          </div>
        </Panel>
      </div>

      <div className="min-w-0 space-y-4">
        <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
          <Stat
            label="Mevcut fiyat"
            value={money(draft.currency, base.price)}
            hint={`Parite %${parity.toFixed(2)}`}
            tone="primary"
          />
          <Stat label="Macaulay durasyon" value={`${num(base.mac)} yıl`} hint="Ağırlıklı nakit vadesi" tone="up" />
          <Stat
            label="Modifiye durasyon"
            value={`${num(base.mod)} yıl`}
            hint="100 bps faiz hassasiyeti"
            tone="warn"
          />
          <Stat label="Konveksite" value={num(base.conv)} hint="İkinci derece eğrilik" tone="iris" />
        </div>

        <Panel
          title="Faiz şoku: tam fiyat ve Taylor"
          action={
            <span className="font-mono text-xs text-primary">Yeni getiri %{newYtm.toFixed(2)}</span>
          }
        >
          <div className="grid gap-3 md:grid-cols-3">
            <ShockCard title="Gerçek fiyat (DCF)" price={exact.price} base={base.price} currency={draft.currency} />
            <ShockCard
              title="Yalnız durasyon"
              price={shock.durationOnly}
              base={base.price}
              currency={draft.currency}
            />
            <ShockCard
              title="Durasyon + konveksite"
              price={shock.taylor}
              base={base.price}
              currency={draft.currency}
            />
          </div>
        </Panel>

        <Panel
          title="Fiyat – getiri eğrisi"
          action={
            <span className="text-xs text-muted">
              <span className="text-primary">Düz çizgi</span> gerçek eğri ·{" "}
              <span className="text-warn">Kesik çizgi</span> durasyon teğeti
            </span>
          }
        >
          <YieldChart points={curve} currency={draft.currency} />
        </Panel>

        <Panel
          title="Nakit akışları"
          action={
            <div className="flex items-center gap-2">
              <span className="text-xs text-primary">{base.flows.length} dönem</span>
              <Button
                onClick={() => {
                  const header =
                    "Donem;Vade_Yil;Kupon;Anapara;Toplam_CF;Iskonto_DF;Bugunku_Deger_PV;Agirlik_Yuzde";
                  const body = base.flows
                    .map((flow) =>
                      [
                        flow.t,
                        flow.yr.toFixed(2),
                        flow.cp.toFixed(2),
                        flow.pr.toFixed(2),
                        flow.cf.toFixed(2),
                        flow.df.toFixed(6),
                        flow.pv.toFixed(2),
                        flow.w.toFixed(2),
                      ].join(";"),
                    )
                    .join("\r\n");
                  downloadCsv(`${draft.code || "Tahvil"}_Nakit_Akimlari.csv`, `${header}\r\n${body}\r\n`);
                }}
              >
                <Download className="size-4" />
                CSV
              </Button>
            </div>
          }
        >
          <div className="max-h-80 overflow-auto rounded-lg border border-line">
            <table className="w-full min-w-[46rem] text-left text-sm">
              <thead className="sticky top-0 bg-bg text-xs uppercase tracking-wide text-muted">
                <tr>
                  {["Dönem", "Vade", "Kupon", "Anapara", "Nakit", "İskonto", "Bugünkü değer", "Ağırlık"].map(
                    (head) => (
                      <th key={head} className="px-3 py-2 font-medium">
                        {head}
                      </th>
                    ),
                  )}
                </tr>
              </thead>
              <tbody>
                {base.flows.map((flow) => (
                  <tr key={flow.t} className="border-t border-line">
                    <td className="px-3 py-2 font-mono text-primary">{flow.t}</td>
                    <td className="px-3 py-2 font-mono tabular-nums">{flow.yr.toFixed(2)}</td>
                    <td className="px-3 py-2 font-mono tabular-nums">{money(draft.currency, flow.cp)}</td>
                    <td className="px-3 py-2 font-mono tabular-nums">
                      {flow.pr > 0 ? money(draft.currency, flow.pr) : "—"}
                    </td>
                    <td className="px-3 py-2 font-mono font-semibold tabular-nums">
                      {money(draft.currency, flow.cf)}
                    </td>
                    <td className="px-3 py-2 font-mono tabular-nums">{flow.df.toFixed(4)}</td>
                    <td className="px-3 py-2 font-mono font-semibold tabular-nums text-up">
                      {money(draft.currency, flow.pv)}
                    </td>
                    <td className="px-3 py-2 font-mono tabular-nums">%{flow.w.toFixed(1)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>

        <Panel
          title="Portföy"
          action={
            <div className="flex flex-wrap gap-2">
              <Button onClick={() => fileRef.current?.click()}>
                <Upload className="size-4" />
                İçe aktar
              </Button>
              <Button
                onClick={() => {
                  if (!portfolio.length) {
                    setNotice("Portföy boş.");
                    return;
                  }
                  downloadCsv("Finport_Tahvil_Portfoyu.csv", portfolioToCsv(portfolio));
                }}
              >
                <Download className="size-4" />
                İndir
              </Button>
              <Button onClick={() => downloadCsv("Tahvil_Portfoy_Sablonu.csv", portfolioTemplateCsv())}>
                Şablon
              </Button>
              <Button
                onClick={() => {
                  onPortfolio([
                    { id: crypto.randomUUID(), code: "TRT200928T19", type: "fixed", currency: draft.currency, qty: 200, price: 945.2, mod: 3.45, conv: 15.2 },
                    { id: crypto.randomUUID(), code: "TRT140727T12", type: "zero", currency: draft.currency, qty: 150, price: 680.5, mod: 1.85, conv: 4.1 },
                    { id: crypto.randomUUID(), code: "TRT120133T11", type: "tufex", currency: draft.currency, qty: 100, price: 1320, mod: 5.4, conv: 35.8 },
                    { id: crypto.randomUUID(), code: "TRT080426T15", type: "frn", currency: draft.currency, qty: 250, price: 1008.1, mod: 0.25, conv: 0.1 },
                  ]);
                  setNotice("Örnek portföy yüklendi. Mevcut satırların yerini alır.");
                }}
              >
                Örnek
              </Button>
              {confirmClear ? (
                <Button
                  variant="danger"
                  onClick={() => {
                    onPortfolio([]);
                    setConfirmClear(false);
                    setNotice("Portföy temizlendi.");
                  }}
                >
                  Emin misiniz?
                </Button>
              ) : (
                <Button variant="danger" onClick={() => setConfirmClear(true)}>
                  Temizle
                </Button>
              )}
            </div>
          }
        >
          <input
            ref={fileRef}
            type="file"
            accept=".csv,text/csv"
            className="hidden"
            onChange={(event) => {
              const file = event.target.files?.[0];
              event.target.value = "";
              if (file) onImport(file);
            }}
          />
          {notice ? <p className="mb-3 text-sm text-muted">{notice}</p> : null}
          {portfolio.length === 0 ? (
            <p className="rounded-lg border border-dashed border-line px-4 py-8 text-center text-sm text-faint">
              Henüz tahvil yok. Soldan ekleyin, örnek yükleyin veya CSV içe aktarın.
            </p>
          ) : (
            <div className="space-y-4">
              <div className="grid gap-3 md:grid-cols-2">
                {[...groups.entries()].map(([currency, items]) => {
                  const total = items.reduce((sum, item) => sum + item.price * item.qty, 0);
                  const wDur = items.reduce((sum, item) => sum + item.mod * item.price * item.qty, 0);
                  const wConv = items.reduce((sum, item) => sum + item.conv * item.price * item.qty, 0);
                  const avgDur = total > 0 ? wDur / total : 0;
                  const avgConv = total > 0 ? wConv / total : 0;
                  const book = taylorShock(total, avgDur, avgConv, dyBps);
                  const moved = book.taylor - total;
                  return (
                    <div key={currency} className="grid grid-cols-2 gap-3">
                      <Stat label={`${currency} değer`} value={money(currency, total)} />
                      <Stat label="Ağırlıklı durasyon" value={`${num(avgDur)} yıl`} tone="warn" />
                      <Stat label="Ağırlıklı konveksite" value={num(avgConv)} tone="iris" />
                      <Stat
                        label={`Şok ${dyBps >= 0 ? "+" : ""}${dyBps} bps`}
                        value={`${moved >= 0 ? "+" : ""}${money(currency, moved)}`}
                        hint={book.pct >= 0 ? `+${(book.pct * 100).toFixed(2)}%` : `${(book.pct * 100).toFixed(2)}%`}
                        tone={moved >= 0 ? "up" : "down"}
                      />
                    </div>
                  );
                })}
              </div>
              <div className="overflow-x-auto rounded-lg border border-line">
                <table className="w-full min-w-[44rem] text-left text-sm">
                  <thead className="bg-bg text-xs uppercase tracking-wide text-muted">
                    <tr>
                      {["Kod", "Tür", "Adet", "Birim fiyat", "Toplam", "Ağırlık", "Mod. durasyon", ""].map(
                        (head) => (
                          <th key={head || "act"} className="px-3 py-2 font-medium">
                            {head}
                          </th>
                        ),
                      )}
                    </tr>
                  </thead>
                  <tbody>
                    {portfolio.map((item) => {
                      const peers = groups.get(item.currency) ?? [];
                      const groupTotal = peers.reduce((sum, peer) => sum + peer.price * peer.qty, 0);
                      const value = item.price * item.qty;
                      const weight = groupTotal > 0 ? (value / groupTotal) * 100 : 0;
                      return (
                        <tr key={item.id} className="border-t border-line">
                          <td className="px-3 py-2 font-mono font-semibold text-primary">{item.code}</td>
                          <td className="px-3 py-2">{BOND_TYPE_LABEL[item.type]}</td>
                          <td className="px-3 py-2 font-mono tabular-nums">{num(item.qty, 0)}</td>
                          <td className="px-3 py-2 font-mono tabular-nums">{money(item.currency, item.price)}</td>
                          <td className="px-3 py-2 font-mono font-semibold tabular-nums">
                            {money(item.currency, value)}
                          </td>
                          <td className="px-3 py-2 font-mono tabular-nums">%{weight.toFixed(1)}</td>
                          <td className="px-3 py-2 font-mono tabular-nums text-warn">
                            {item.mod.toFixed(2)} yıl
                          </td>
                          <td className="px-3 py-2">
                            <button
                              type="button"
                              className="inline-flex min-h-11 items-center gap-1 text-sm font-semibold text-down"
                              onClick={() => onPortfolio(portfolio.filter((row) => row.id !== item.id))}
                            >
                              <Trash2 className="size-4" />
                              Kaldır
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </Panel>
      </div>
    </div>
  );
}

function ShockCard({
  title,
  price,
  base,
  currency,
}: {
  title: string;
  price: number;
  base: number;
  currency: Currency;
}) {
  const { diff, pct, up } = changeTone(price, base);
  return (
    <div className="rounded-lg border border-line bg-bg p-3">
      <p className="text-xs text-muted">{title}</p>
      <p className="mt-1 font-mono text-lg font-semibold tabular-nums">{money(currency, price)}</p>
      <p className={`mt-1 text-xs font-semibold tabular-nums ${up ? "text-up" : "text-down"}`}>
        {up ? "+" : ""}
        {pct.toFixed(2)}% ({up ? "+" : ""}
        {money(currency, diff)})
      </p>
    </div>
  );
}
