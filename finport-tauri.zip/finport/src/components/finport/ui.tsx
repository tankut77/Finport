import type { ReactNode } from "react";
import { cn } from "@/lib/cn";

export const controlClass =
  "min-h-11 w-full min-w-0 max-w-full rounded-lg border border-line bg-bg px-3 text-sm text-ink outline-none transition-colors focus:border-primary";

export function Panel({
  title,
  action,
  children,
  className,
}: {
  title: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={cn("rounded-card border border-line bg-surface p-4 sm:p-5", className)}>
      <header className="mb-4 flex flex-wrap items-start justify-between gap-3 border-b border-line pb-3">
        <h2 className="text-sm font-semibold text-ink">{title}</h2>
        {action}
      </header>
      {children}
    </section>
  );
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block min-w-0">
      <span className="mb-1.5 block text-xs font-medium text-muted">{label}</span>
      {children}
    </label>
  );
}

export function TextInput({
  value,
  onChange,
}: {
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <input className={controlClass} value={value} onChange={(event) => onChange(event.target.value)} />
  );
}

export function NumInput({
  value,
  onChange,
  step = 1,
  min,
  max,
}: {
  value: number;
  onChange: (value: number) => void;
  step?: number;
  min?: number;
  max?: number;
}) {
  return (
    <input
      className={cn(controlClass, "font-mono tabular-nums")}
      type="number"
      value={Number.isFinite(value) ? value : 0}
      step={step}
      min={min}
      max={max}
      onChange={(event) => {
        const next = event.target.valueAsNumber;
        if (Number.isFinite(next)) onChange(next);
      }}
    />
  );
}

export function SelectInput<T extends string | number>({
  value,
  onChange,
  options,
}: {
  value: T;
  onChange: (value: T) => void;
  options: { value: T; label: string }[];
}) {
  return (
    <select
      className={controlClass}
      value={String(value)}
      onChange={(event) => {
        const match = options.find((option) => String(option.value) === event.target.value);
        if (match) onChange(match.value);
      }}
    >
      {options.map((option) => (
        <option key={String(option.value)} value={String(option.value)}>
          {option.label}
        </option>
      ))}
    </select>
  );
}

export function Stat({
  label,
  value,
  hint,
  tone = "ink",
}: {
  label: string;
  value: string;
  hint?: string;
  tone?: "ink" | "primary" | "up" | "down" | "warn" | "iris";
}) {
  const toneClass = {
    ink: "text-ink",
    primary: "text-primary",
    up: "text-up",
    down: "text-down",
    warn: "text-warn",
    iris: "text-iris",
  }[tone];
  return (
    <div className="rounded-xl border border-line bg-bg px-4 py-3">
      <div className="text-xs text-muted">{label}</div>
      <div className={cn("mt-1 font-mono text-lg font-semibold tabular-nums sm:text-xl", toneClass)}>
        {value}
      </div>
      {hint ? <div className="mt-1 text-xs text-faint">{hint}</div> : null}
    </div>
  );
}
