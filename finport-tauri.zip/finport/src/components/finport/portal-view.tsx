import { ArrowUpRight } from "lucide-react";
import { TOOL_GROUPS } from "@/lib/finance/catalog";
import { isTauri, openExternal } from "@/lib/platform";

export function PortalView() {
  return (
    <div className="space-y-8">
      <p className="max-w-3xl text-sm text-muted">
        Değerleme ve tahvil girdilerini doldurmadan önce bakılacak yirmi kaynak. Bağlantılar
        tarayıcıda açılır; Finport bu sitelerden veri çekmez.
      </p>
      {TOOL_GROUPS.map((group) => (
        <section key={group.title}>
          <h2 className="border-l-2 border-primary pl-3 text-sm font-semibold text-ink">{group.title}</h2>
          <p className="mt-1 pl-3.5 text-xs text-faint">{group.blurb}</p>
          <div className="mt-3 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            {group.links.map((link) => (
              <a
                key={link.href}
                href={link.href}
                target="_blank"
                rel="noreferrer"
                onClick={(event) => {
                  if (!isTauri) return;
                  event.preventDefault();
                  void openExternal(link.href);
                }}
                className="group rounded-card border border-line bg-surface p-4 transition-colors hover:border-primary"
              >
                <div className="flex items-start justify-between gap-3">
                  <h3 className="font-semibold text-primary">{link.name}</h3>
                  <ArrowUpRight className="size-4 shrink-0 text-faint transition-colors group-hover:text-primary" />
                </div>
                <p className="mt-2 text-sm text-muted">{link.detail}</p>
              </a>
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}
