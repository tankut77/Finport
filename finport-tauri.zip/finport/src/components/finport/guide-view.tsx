import type { TabId } from "@/lib/finance/model";
import { Button } from "@/components/ui/button";
import { Panel } from "@/components/finport/ui";

function Step({ n, title, children }: { n: string; title: string; children: string }) {
  return (
    <div className="flex gap-3 rounded-lg border border-line bg-bg p-3">
      <span className="grid size-7 shrink-0 place-items-center rounded-full border border-primary/40 bg-primary/10 text-xs font-semibold text-primary">
        {n}
      </span>
      <div>
        <h3 className="text-sm font-semibold text-ink">{title}</h3>
        <p className="mt-1 text-sm text-muted">{children}</p>
      </div>
    </div>
  );
}

export function GuideView({ onTab }: { onTab: (tab: TabId) => void }) {
  return (
    <div className="space-y-5">
      <section className="rounded-card border border-line border-l-4 border-l-primary bg-surface p-5">
        <h2 className="text-xl font-semibold text-primary">Finport nasıl kullanılır</h2>
        <p className="mt-2 max-w-3xl text-sm text-muted">
          Üç iş var: kaynakları açmak, bir tahvilin faiz hassasiyetini ölçmek ve bir şirkete beş
          farklı yöntemle içsel değer biçmek. Hesaplar bu tarayıcıda kalır. Portföy ve son
          girdiler yalnızca bu cihazda saklanır; bir sunucuya gönderilmez.
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          <Button onClick={() => onTab("bonds")}>Tahvil modülü</Button>
          <Button onClick={() => onTab("valuation")}>Değerleme modülü</Button>
        </div>
      </section>

      <div className="grid gap-5 lg:grid-cols-2">
        <Panel title="Verileri nereden alacaksınız">
          <div className="space-y-3">
            <Step n="1" title="Risksiz faiz">
              ABD için 10 yıllık hazine getirisini FRED’den, politika faizi olasılığını CME FedWatch’tan okuyun. Türkiye tahvillerinde iskonto oranını o kağıdın piyasa bileşik getirisinden alın.
            </Step>
            <Step n="2" title="Serbest nakit ve borç">
              DCF’e gireceğiniz serbest nakit akımı, FAVÖK ve net borcu Roic.ai, Macrotrends veya StockAnalysis üzerinden aynı birimde (örneğin milyon) yazın.
            </Step>
            <Step n="3" title="Risk primi ve çarpan">
              CAPM’deki piyasa risk primi ile sektör FD/FAVÖK ortalamaları için Damodaran veri setleri yaygın referanstır. Çarpanlar emsaldir, kesin değer değildir.
            </Step>
          </div>
        </Panel>
        <Panel title="Ne yatırım tavsiyesi değildir">
          <div className="space-y-3">
            <Step n="A" title="Model fiyatı piyasa fiyatı değildir">
              Durasyon yaklaşımı küçük faiz değişimlerinde işe yarar. Büyük şoklarda gerçek indirgenmiş nakit akışı ile Taylor tahminini yan yana koyun; aradaki fark konveksiteden gelir.
            </Step>
            <Step n="B" title="Birim tutarlılığı">
              Şirket düzeyindeki tutarlar pay adediyle aynı birimdedir. Pay adedi 100 milyon ise FCF ve borç da milyon cinsinden girilir. Hisse başı sonuç o zaman fiyat birimindedir.
            </Step>
            <Step n="C" title="Sinyal eşiği">
              İçsel değer piyasa fiyatının en az %15 üstündeyse iskontolu, %15 altındaysa primli sayılır. Ara bölge adil değer olarak işaretlenir.
            </Step>
          </div>
        </Panel>
      </div>

      <Panel title="Tahvil, bono ve portföy">
        <div className="grid gap-4 lg:grid-cols-2">
          <div className="space-y-3">
            <Step n="1" title="Dört enstrüman">
              Sabit kupon klasik eurobond ve devlet tahvilidir. İskontolu bonoda kupon yoktur, Macaulay durasyon vadeye eşittir. Değişken faiz (FRN) riski bir sonraki kupon sıfırlamasına kadardır. TÜFEX / TIPS’te anapara endeks katsayısıyla büyür; getiri alanına reel getiri yazılır.
            </Step>
            <Step n="2" title="Faiz şoku">
              −200 ile +200 baz puan düğmeleri paralel getiri kaymasıdır. Sağdaki üç kart gerçek DCF fiyatını, yalnız durasyonu ve durasyon artı konveksiteyi karşılaştırır.
            </Step>
          </div>
          <div className="space-y-3">
            <Step n="3" title="Portföy dosyası">
              Hesaplanan kağıdı sepete ekleyin veya şablonu indirip Excel’de doldurun. Ayraç noktalı virgüldür. Sütunlar: kod, tür (fixed, zero, frn, tufex), para birimi, adet, fiyat, modifiye durasyon, konveksite. Karışık para birimleri ayrı toplanır.
            </Step>
            <pre className="overflow-x-auto rounded-lg border border-line border-l-4 border-l-warn bg-bg p-3 font-mono text-xs leading-6 text-warn">
              {`Macaulay = Σ (t × PV(CFₜ)) / P₀
Modifiye D* = Macaulay / (1 + YTM / m)
ΔP/P ≈ −D* × Δy + ½ × Konveksite × (Δy)²`}
            </pre>
          </div>
        </div>
      </Panel>

      <Panel title="Beş değerleme yöntemi">
        <div className="grid gap-4 lg:grid-cols-2">
          <div className="space-y-3 text-sm text-muted">
            <p>
              <strong className="text-ink">DCF.</strong> Beş yıl büyüyen serbest nakit, sonra sonsuz büyüme ile uç değer. Özkaynak = indirgenmiş nakiller + indirgenmiş uç değer − net borç.
            </p>
            <p>
              <strong className="text-ink">Çarpan.</strong> F/K, FD/FAVÖK ve PD/DD hedef fiyatlarının ortalaması. FD/FAVÖK hisse başı değere net borç düşülerek iner.
            </p>
            <p>
              <strong className="text-ink">Gordon temettü modeli.</strong> Düzenli kâr payı dağıtan olgun şirketler için. D₁ / (Ke − g).
            </p>
            <p>
              <strong className="text-ink">NAV.</strong> Piyasa değerli aktifler eksi yükümlülükler, paya bölünür. Holding ve GYO bilançolarında daha anlamlıdır.
            </p>
            <p>
              <strong className="text-ink">Tasfiye.</strong> Varlıklara acil satış iskontosu, sonra borç ve tasfiye gideri. En kötü senaryo tabanıdır.
            </p>
          </div>
          <pre className="overflow-x-auto rounded-lg border border-line border-l-4 border-l-warn bg-bg p-3 font-mono text-xs leading-6 text-warn">
            {`Ke = Rf + β × ERP
Uç değer = FCF₅ × (1 + g) / (WACC − g)
Özkaynak = Σ PV(FCF) + PV(uç değer) − net borç
Hisse başı = özkaynak / pay adedi`}
          </pre>
        </div>
      </Panel>
    </div>
  );
}
