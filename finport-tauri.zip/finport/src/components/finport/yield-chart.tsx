import { useEffect, useState } from "react";
import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { CurvePoint } from "@/lib/finance/bonds";
import { money } from "@/lib/finance/format";
import type { Currency } from "@/lib/finance/model";

export function YieldChart({ points, currency }: { points: CurvePoint[]; currency: Currency }) {
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);

  if (!ready) {
    return <div className="h-64 rounded-lg border border-dashed border-line" />;
  }

  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={points} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
          <CartesianGrid stroke="var(--color-line)" vertical={false} />
          <XAxis
            dataKey="ytm"
            tickFormatter={(value: number) => `${value.toFixed(1)}%`}
            tick={{ fill: "var(--color-muted)", fontSize: 12 }}
            stroke="var(--color-line)"
          />
          <YAxis
            tickFormatter={(value: number) => money(currency, value, 0)}
            tick={{ fill: "var(--color-muted)", fontSize: 12 }}
            stroke="var(--color-line)"
            width={72}
          />
          <Tooltip
            contentStyle={{
              background: "var(--color-surface)",
              border: "1px solid var(--color-line)",
              borderRadius: 8,
              color: "var(--color-ink)",
            }}
            formatter={(value, name) => {
              const amount = typeof value === "number" ? value : Number(value);
              const label = name === "tangent" ? "Durasyon teğeti" : "Gerçek fiyat";
              return [money(currency, amount), label];
            }}
            labelFormatter={(label) => `Getiri %${Number(label).toFixed(2)}`}
          />
          <Line
            type="monotone"
            dataKey="price"
            name="price"
            stroke="var(--color-primary)"
            strokeWidth={2.5}
            dot={false}
          />
          <Line
            type="monotone"
            dataKey="tangent"
            name="tangent"
            stroke="var(--color-warn)"
            strokeDasharray="5 5"
            strokeWidth={1.5}
            dot={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
