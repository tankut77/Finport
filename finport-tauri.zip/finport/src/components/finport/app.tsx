import { useEffect, useState } from "react";
import { BookOpen, Building2, Landmark, Link2 } from "lucide-react";
import { BondsView } from "@/components/finport/bonds-view";
import { GuideView } from "@/components/finport/guide-view";
import { PortalView } from "@/components/finport/portal-view";
import { ValuationView } from "@/components/finport/valuation-view";
import { cn } from "@/lib/cn";
import { loadAppState, saveAppState } from "@/lib/finance/storage";
import { defaultAppState, type AppState, type TabId } from "@/lib/finance/model";

const NAV: { id: TabId; label: string; short: string; icon: typeof Link2 }[] = [
  { id: "portal", label: "Araç portalı", short: "Portal", icon: Link2 },
  { id: "bonds", label: "Tahvil ve portföy", short: "Tahvil", icon: Landmark },
  { id: "valuation", label: "Şirket değerleme", short: "Değerleme", icon: Building2 },
  { id: "guide", label: "Kılavuz", short: "Kılavuz", icon: BookOpen },
];

export function FinportApp() {
  const [state, setState] = useState<AppState>(defaultAppState);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    const saved = loadAppState();
    if (saved) setState(saved);
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    saveAppState(state);
  }, [state, hydrated]);

  return (
    <div className="min-h-screen bg-bg text-ink">
      <header className="sticky top-0 z-20 pt-[env(safe-area-inset-top)] border-b border-line border-t-2 border-t-primary bg-surface/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-col gap-3 px-4 py-3 sm:px-6 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex items-center gap-3">
            <span className="grid size-10 place-items-center rounded-lg bg-primary text-primary-ink">
              <Landmark className="size-5" aria-hidden="true" />
            </span>
            <div>
              <p className="text-base font-semibold tracking-tight">Finport</p>
              <p className="text-xs text-muted">Tahvil durasyonu, portföy ve şirket değerleme</p>
            </div>
          </div>
          <nav
            className="flex w-full min-w-0 max-w-full gap-1 overflow-x-auto rounded-xl border border-line bg-bg p-1"
            aria-label="Bölümler"
          >
            {NAV.map((item) => {
              const Icon = item.icon;
              const active = state.tab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  aria-current={active ? "page" : undefined}
                  onClick={() => setState((current) => ({ ...current, tab: item.id }))}
                  className={cn(
                    "inline-flex min-h-11 shrink-0 items-center gap-2 rounded-lg px-3 text-sm font-semibold",
                    active ? "bg-primary text-primary-ink" : "text-muted hover:bg-raised hover:text-ink",
                  )}
                >
                  <Icon className="size-4" aria-hidden="true" />
                  <span className="sm:hidden">{item.short}</span>
                  <span className="hidden sm:inline">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-5 pb-[calc(1.25rem+env(safe-area-inset-bottom))] sm:px-6 sm:py-6">
        {state.tab === "portal" ? <PortalView /> : null}
        {state.tab === "bonds" ? (
          <BondsView
            draft={state.bond}
            dyBps={state.dyBps}
            portfolio={state.portfolio}
            onDraft={(bond) => setState((current) => ({ ...current, bond }))}
            onDy={(dyBps) => setState((current) => ({ ...current, dyBps }))}
            onPortfolio={(portfolio) => setState((current) => ({ ...current, portfolio }))}
          />
        ) : null}
        {state.tab === "valuation" ? (
          <ValuationView
            draft={state.valuation}
            onDraft={(valuation) => setState((current) => ({ ...current, valuation }))}
          />
        ) : null}
        {state.tab === "guide" ? (
          <GuideView onTab={(tab) => setState((current) => ({ ...current, tab }))} />
        ) : null}
        <p className="mt-8 text-xs text-faint">
          Senaryo aracıdır, yatırım tavsiyesi değildir. Sonuçlar girdiğiniz varsayımlara bağlıdır.
        </p>
      </main>
    </div>
  );
}
