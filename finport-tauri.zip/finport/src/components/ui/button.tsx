import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/cn";

type Variant = "primary" | "soft" | "ghost" | "danger";

export function Button({
  variant = "soft",
  className,
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }) {
  return (
    <button
      type={type}
      className={cn(
        "inline-flex min-h-11 items-center justify-center gap-2 rounded-lg px-3 text-sm font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-50",
        variant === "primary" && "bg-primary text-primary-ink hover:bg-primary/90",
        variant === "soft" &&
          "border border-primary/30 bg-primary/10 text-primary hover:bg-primary hover:text-primary-ink",
        variant === "ghost" && "border border-line bg-raised text-ink hover:border-primary",
        variant === "danger" && "border border-line bg-transparent text-down hover:bg-down/10",
        className,
      )}
      {...props}
    />
  );
}
