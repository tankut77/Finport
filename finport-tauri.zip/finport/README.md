# Finport

Tahvil durasyonu, portföy faiz şoku ve şirket değerleme aracı. Tarayıcıdan bağımsız,
Tauri 2 ile Windows / macOS / Linux / iOS / Android olarak derlenir.
Veri çekmez; portföy CSV ile yüklenir, durum cihazda saklanır.

## Gereksinimler
- Node.js 20+
- Rust (https://rustup.rs)
- Tauri ön koşulları: https://v2.tauri.app/start/prerequisites/
  - Windows: WebView2 + Visual Studio C++ Build Tools
  - macOS: Xcode (iOS için de gerekli)
  - Android: Android Studio, SDK + NDK, `JAVA_HOME`, `ANDROID_HOME`, `NDK_HOME`

## İlk kurulum
```bash
npm install
npm run tauri icon app-icon.png     # src-tauri/icons klasörünü üretir
```

## Masaüstü
```bash
npm run tauri dev       # geliştirme
npm run tauri build     # kurulum paketi (src-tauri/target/release/bundle)
```

## Mobil
```bash
npm run tauri android init    # bir kez
npm run tauri android dev
npm run tauri android build

npm run tauri ios init        # bir kez, yalnızca macOS
npm run tauri ios dev
npm run tauri ios build
```

## Tarayıcıda hızlı deneme
`npm run dev` ile http://localhost:1420 açılır (CSV kaydetme normal indirme olarak çalışır).

## Notlar
- CSV içe aktarma standart dosya seçici ile çalışır (tüm platformlarda).
- CSV dışa aktarma masaüstünde yerel "Kaydet" penceresi kullanır. Mobilde
  `plugin-dialog` kaydetme penceresi sınırlı olabilir; denemeden emin olma.
  Sorun çıkarsa `src/lib/platform.ts` içindeki `saveTextFile` paylaşım menüsüne çevrilebilir.
- Fontlar pakete gömülüdür, internet gerekmez.
